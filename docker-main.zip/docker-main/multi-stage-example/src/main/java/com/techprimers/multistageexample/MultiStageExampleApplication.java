package com.techprimers.multistageexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiStageExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiStageExampleApplication.class, args);
	}

}
